Rubiks-cube-solver
==============================================================================

Rubiks-cube-solver is a Rubik's cube simulator where you can play with a virtual 3x3 rubk's cube and learn how to solve it.
It provides a step-by-step solution to solve the cube. The algorithm used for solving the cube is a layer-wise approach, that we usually use for solving it.

### Getting started
You can either:
1. checkout the [Live Demo](https://rama-rubik.herokuapp.com/index.html) or
2. download the source code and just open index.html in your browser!
